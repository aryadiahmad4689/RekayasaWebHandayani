<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Document</title>
</head>
<body>

    <form action="sumber2.php" action="get">
    <p>Nip</p>
    <input type="text" name="nip">
    <p>Nama</p>
    <input type="text" name="nama">
    <p>Tahun Masuk</p>
    <input type="text" name="tahunMasuk">

    <button type="submit" name="kirim">Proses</button>
    
    
    </form>
</body>
</html>